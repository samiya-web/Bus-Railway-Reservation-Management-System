# Bus and Railway Reservation Management System (C)

## Requirements
- GCC compiler (or another C compiler)
- No third-party libraries

## Compile
Windows (MinGW):
```bash
gcc main.c -o reservation.exe
reservation.exe
```

Linux/macOS:
```bash
gcc main.c -o reservation
./reservation
```

## Features
- View sample bus and train services
- Book bus and railway tickets
- Calculate fare automatically
- Track available seats
- View booking by booking ID
- Cancel bookings and restore seats
- List all bookings
- Save bookings between runs in `reservations.txt`

## Important
This is a local educational project. The sample services and dates are for demonstration only. It does not connect to live bus operators, IRCTC, payment gateways, or real inventory. Booking IDs are not official PNRs.
