/*
 * Bus and Railway Reservation Management System
 * Language: C
 * Storage: Local text file (reservations.txt)
 *
 * Compile:
 *   gcc main.c -o reservation
 * Run:
 *   ./reservation       (Linux/macOS)
 *   reservation.exe     (Windows)
 *
 * This is an educational demo with sample services, not a live booking system.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SERVICES 10
#define MAX_BOOKINGS 500
#define NAME_LEN 60
#define SERVICE_LEN 60
#define FILE_NAME "reservations.txt"

typedef struct {
    int id;
    char type[10];
    char name[SERVICE_LEN];
    char source[40];
    char destination[40];
    char date[16];
    char time[8];
    double fare;
    int totalSeats;
    int availableSeats;
} Service;

typedef struct {
    int bookingId;
    int serviceId;
    char passenger[NAME_LEN];
    int age;
    int seats;
    double totalFare;
    int active;
} Booking;

Service services[MAX_SERVICES] = {
    {1, "BUS", "Express Bus B101", "Agra", "Delhi", "2026-10-05", "08:00", 450, 40, 40},
    {2, "BUS", "Volvo Bus B205", "Agra", "Jaipur", "2026-10-05", "09:30", 650, 35, 35},
    {3, "BUS", "Night Bus B310", "Delhi", "Lucknow", "2026-10-06", "21:00", 800, 40, 40},
    {4, "TRAIN", "Taj Express 12280", "Agra", "Delhi", "2026-10-05", "07:00", 250, 60, 60},
    {5, "TRAIN", "Intercity 12179", "Agra", "Jaipur", "2026-10-05", "15:00", 380, 60, 60},
    {6, "TRAIN", "Gomti Express 12419", "Lucknow", "Delhi", "2026-10-06", "18:00", 520, 80, 80}
};
int serviceCount = 6;
Booking bookings[MAX_BOOKINGS];
int bookingCount = 0;
int nextBookingId = 1001;

void pauseScreen(void) {
    printf("\nPress Enter to continue...");
    while (getchar() != '\n') {}
}

int readInt(const char *prompt, int minValue, int maxValue) {
    char line[100];
    int value;
    while (1) {
        printf("%s", prompt);
        if (!fgets(line, sizeof(line), stdin)) return minValue;
        if (sscanf(line, "%d", &value) == 1 && value >= minValue && value <= maxValue)
            return value;
        printf("Please enter a number from %d to %d.\n", minValue, maxValue);
    }
}

void readText(const char *prompt, char *out, size_t size) {
    printf("%s", prompt);
    if (fgets(out, (int)size, stdin)) {
        out[strcspn(out, "\n")] = '\0';
    } else {
        out[0] = '\0';
    }
}

int findService(int id) {
    for (int i = 0; i < serviceCount; i++)
        if (services[i].id == id) return i;
    return -1;
}

void saveBookings(void) {
    FILE *fp = fopen(FILE_NAME, "w");
    if (!fp) {
        printf("Warning: could not save bookings.\n");
        return;
    }
    fprintf(fp, "%d %d\n", nextBookingId, bookingCount);
    for (int i = 0; i < bookingCount; i++) {
        Booking *b = &bookings[i];
        /* Names with spaces are stored using a pipe-delimited record. */
        fprintf(fp, "%d|%d|%s|%d|%d|%.2f|%d\n",
                b->bookingId, b->serviceId, b->passenger, b->age,
                b->seats, b->totalFare, b->active);
    }
    fclose(fp);
}

void loadBookings(void) {
    FILE *fp = fopen(FILE_NAME, "r");
    if (!fp) return;
    if (fscanf(fp, "%d %d\n", &nextBookingId, &bookingCount) != 2) {
        fclose(fp);
        bookingCount = 0;
        nextBookingId = 1001;
        return;
    }
    if (bookingCount < 0 || bookingCount > MAX_BOOKINGS) {
        bookingCount = 0;
        nextBookingId = 1001;
        fclose(fp);
        return;
    }

    for (int i = 0; i < bookingCount; i++) {
        char line[300];
        if (!fgets(line, sizeof(line), fp)) {
            bookingCount = i;
            break;
        }
        Booking *b = &bookings[i];
        if (sscanf(line, "%d|%d|%59[^|]|%d|%d|%lf|%d",
                   &b->bookingId, &b->serviceId, b->passenger, &b->age,
                   &b->seats, &b->totalFare, &b->active) != 7) {
            bookingCount = i;
            break;
        }
    }
    fclose(fp);

    /* Recalculate seat availability from active saved bookings. */
    for (int i = 0; i < serviceCount; i++)
        services[i].availableSeats = services[i].totalSeats;
    for (int i = 0; i < bookingCount; i++) {
        if (bookings[i].active) {
            int s = findService(bookings[i].serviceId);
            if (s >= 0) {
                services[s].availableSeats -= bookings[i].seats;
                if (services[s].availableSeats < 0) services[s].availableSeats = 0;
            }
        }
    }
}

void showServices(const char *type) {
    printf("\n%-4s %-6s %-25s %-22s %-12s %-6s %8s %7s\n",
           "ID", "Type", "Service", "Route", "Date", "Time", "Fare", "Seats");
    printf("-----------------------------------------------------------------------------------------------\n");
    int found = 0;
    for (int i = 0; i < serviceCount; i++) {
        Service *s = &services[i];
        if ((!type || strcmp(s->type, type) == 0) && s->availableSeats > 0) {
            char route[90];
            snprintf(route, sizeof(route), "%s -> %s", s->source, s->destination);
            printf("%-4d %-6s %-25.25s %-22.22s %-12s %-6s Rs.%6.0f %7d\n",
                   s->id, s->type, s->name, route, s->date, s->time,
                   s->fare, s->availableSeats);
            found = 1;
        }
    }
    if (!found) printf("No available services found.\n");
}

void bookTicket(const char *type) {
    showServices(type);
    int id = readInt("\nEnter service ID (0 to go back): ", 0, 999999);
    if (id == 0) return;
    int index = findService(id);
    if (index < 0 || strcmp(services[index].type, type) != 0) {
        printf("Invalid service ID.\n");
        return;
    }

    char name[NAME_LEN];
    readText("Passenger name: ", name, sizeof(name));
    if (name[0] == '\0' || strchr(name, '|')) {
        printf("Please enter a valid name (do not use the | character).\n");
        return;
    }
    int age = readInt("Passenger age: ", 1, 120);
    int seats = readInt("Number of seats: ", 1, 100);
    if (seats > services[index].availableSeats) {
        printf("Only %d seat(s) are available.\n", services[index].availableSeats);
        return;
    }
    if (bookingCount >= MAX_BOOKINGS) {
        printf("Booking limit reached.\n");
        return;
    }

    Booking *b = &bookings[bookingCount++];
    b->bookingId = nextBookingId++;
    b->serviceId = id;
    strcpy(b->passenger, name);
    b->age = age;
    b->seats = seats;
    b->totalFare = services[index].fare * seats;
    b->active = 1;
    services[index].availableSeats -= seats;
    saveBookings();

    printf("\nBooking confirmed!\n");
    printf("Booking ID : %d\nPassenger  : %s\nService    : %s\n",
           b->bookingId, b->passenger, services[index].name);
    printf("Route      : %s -> %s\nDate       : %s\nDeparture  : %s\n",
           services[index].source, services[index].destination,
           services[index].date, services[index].time);
    printf("Seats      : %d\nTotal fare : Rs. %.2f\n",
           b->seats, b->totalFare);
}

void viewBooking(void) {
    int id = readInt("Enter booking ID: ", 1, 999999999);
    for (int i = 0; i < bookingCount; i++) {
        Booking *b = &bookings[i];
        if (b->bookingId == id) {
            int s = findService(b->serviceId);
            printf("\n--- BOOKING DETAILS ---\n");
            printf("Booking ID : %d\nPassenger  : %s\nAge        : %d\n",
                   b->bookingId, b->passenger, b->age);
            if (s >= 0) {
                printf("Type       : %s\nService    : %s\n",
                       services[s].type, services[s].name);
                printf("Route      : %s -> %s\nDate       : %s\nTime       : %s\n",
                       services[s].source, services[s].destination,
                       services[s].date, services[s].time);
            }
            printf("Seats      : %d\nFare       : Rs. %.2f\nStatus     : %s\n",
                   b->seats, b->totalFare, b->active ? "CONFIRMED" : "CANCELLED");
            return;
        }
    }
    printf("Booking not found.\n");
}

void cancelBooking(void) {
    int id = readInt("Enter booking ID to cancel: ", 1, 999999999);
    for (int i = 0; i < bookingCount; i++) {
        Booking *b = &bookings[i];
        if (b->bookingId == id) {
            if (!b->active) {
                printf("This booking is already cancelled.\n");
                return;
            }
            int s = findService(b->serviceId);
            b->active = 0;
            if (s >= 0) {
                services[s].availableSeats += b->seats;
                if (services[s].availableSeats > services[s].totalSeats)
                    services[s].availableSeats = services[s].totalSeats;
            }
            saveBookings();
            printf("Booking cancelled. Seats are available again.\n");
            return;
        }
    }
    printf("Booking not found.\n");
}

void showAllBookings(void) {
    if (bookingCount == 0) {
        printf("No bookings have been made yet.\n");
        return;
    }
    printf("\n%-10s %-20s %-6s %-7s %-12s %-10s\n",
           "BookingID", "Passenger", "Seats", "Fare", "Status", "ServiceID");
    printf("---------------------------------------------------------------------\n");
    for (int i = 0; i < bookingCount; i++) {
        Booking *b = &bookings[i];
        printf("%-10d %-20.20s %-6d %-7.2f %-12s %-10d\n",
               b->bookingId, b->passenger, b->seats, b->totalFare,
               b->active ? "CONFIRMED" : "CANCELLED", b->serviceId);
    }
}

int main(void) {
    loadBookings();
    int choice;
    do {
        printf("\n===============================================\n");
        printf(" BUS AND RAILWAY RESERVATION MANAGEMENT SYSTEM\n");
        printf("===============================================\n");
        printf("1. View all available buses and trains\n");
        printf("2. View available buses\n");
        printf("3. Book a bus ticket\n");
        printf("4. View available trains\n");
        printf("5. Book a railway ticket\n");
        printf("6. View booking details\n");
        printf("7. Cancel a booking\n");
        printf("8. View all bookings\n");
        printf("0. Exit\n");
        choice = readInt("Enter your choice: ", 0, 8);

        switch (choice) {
            case 1: showServices(NULL); break;
            case 2: showServices("BUS"); break;
            case 3: bookTicket("BUS"); break;
            case 4: showServices("TRAIN"); break;
            case 5: bookTicket("TRAIN"); break;
            case 6: viewBooking(); break;
            case 7: cancelBooking(); break;
            case 8: showAllBookings(); break;
            case 0: printf("Thank you for using the system.\n"); break;
        }
    } while (choice != 0);
    return 0;
}
